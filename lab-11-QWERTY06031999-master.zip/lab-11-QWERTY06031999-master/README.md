<img src="https://i.imgur.com/a8dE9n6.png"/>


# Lab 11 Assignment:

In this lab exercise, you will learn basic JavaScript by developing a simple calculator application. Please, check `lab11.pdf` file for further instructions.